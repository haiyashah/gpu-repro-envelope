import unittest

from reservation_model import HostTier, counterexample


class ReservationModelTests(unittest.TestCase):
    def test_unreserved_prefetch_can_be_evicted_before_admission(self):
        result = counterexample("unreserved")
        self.assertFalse(result["A_admission_hit"])
        self.assertEqual(result["prefetched_pages_evicted"], 1)

    def test_lease_preserves_completed_prefetch_and_declines_overcommit(self):
        result = counterexample("leased")
        self.assertTrue(result["A_admission_hit"])
        self.assertFalse(result["B_prefetch_accepted"])
        self.assertEqual(result["declined_prefetches"], 1)
        self.assertLessEqual(result["tier_pages_used"], 2)

    def test_pressure_cannot_evict_leased_pages_but_can_use_free_capacity(self):
        tier = HostTier(4, "leased")
        self.assertTrue(tier.start_prefetch("A", 2))
        self.assertTrue(tier.complete_prefetch("A"))
        self.assertTrue(tier.insert_ordinary("background", 2))
        self.assertTrue(tier.admit("A"))
        self.assertEqual(tier.used_pages, 4)

    def test_cancel_releases_lease_for_waiting_prefetch(self):
        tier = HostTier(2, "leased")
        self.assertTrue(tier.start_prefetch("A", 2))
        self.assertFalse(tier.start_prefetch("B", 1))
        self.assertTrue(tier.cancel("A"))
        self.assertTrue(tier.start_prefetch("B", 1))

    def test_admission_requires_completed_transfer(self):
        tier = HostTier(2, "leased")
        self.assertTrue(tier.start_prefetch("A", 1))
        self.assertFalse(tier.admit("A"))
        self.assertTrue(tier.complete_prefetch("A"))
        self.assertTrue(tier.admit("A"))
        self.assertTrue(tier.finish_admission("A"))
        self.assertEqual(tier.used_pages, 0)


if __name__ == "__main__":
    unittest.main()
