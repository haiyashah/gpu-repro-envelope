"""Reference model for keeping prefetched L3 pages alive until admission.

Two policies are modeled. `unreserved` inserts completed L3 reads as ordinary
LRU cache entries, so unrelated host-cache pressure may evict them. `leased`
reserves capacity before issuing the read and protects those pages through
request admission. A refused reservation is an explicit prefetch decline, not a
false promise that a completed prefetch will be available.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections import OrderedDict


@dataclass
class Entry:
    pages: int
    state: str  # prefetching, ready, admitted


class HostTier:
    def __init__(self, capacity_pages: int, policy: str):
        if capacity_pages <= 0:
            raise ValueError("capacity_pages must be positive")
        if policy not in {"unreserved", "leased"}:
            raise ValueError("policy must be 'unreserved' or 'leased'")
        self.capacity = capacity_pages
        self.policy = policy
        self.ordinary: OrderedDict[str, int] = OrderedDict()
        self.prefetches: dict[str, Entry] = {}
        self.prefetch_declines = 0
        self.prefetch_evictions = 0

    @property
    def used_pages(self) -> int:
        return sum(self.ordinary.values()) + sum(
            e.pages for e in self.prefetches.values()
            if self.policy == "leased" or e.state != "prefetching"
        )

    def _make_room(self, pages: int) -> bool:
        while self.used_pages + pages > self.capacity and self.ordinary:
            self.ordinary.popitem(last=False)
        return self.used_pages + pages <= self.capacity

    def start_prefetch(self, request_id: str, pages: int) -> bool:
        if pages <= 0:
            raise ValueError("pages must be positive")
        if request_id in self.prefetches:
            raise ValueError(f"duplicate prefetch {request_id}")
        if self.policy == "leased":
            if not self._make_room(pages):
                self.prefetch_declines += 1
                return False
            self.prefetches[request_id] = Entry(pages, "prefetching")
        else:
            self.prefetches[request_id] = Entry(pages, "prefetching")
        self._check_invariant()
        return True

    def complete_prefetch(self, request_id: str) -> bool:
        entry = self.prefetches.get(request_id)
        if entry is None or entry.state != "prefetching":
            return False
        if self.policy == "unreserved":
            self.ordinary["prefetch:" + request_id] = entry.pages
            self.ordinary.move_to_end("prefetch:" + request_id)
            del self.prefetches[request_id]
            while self.used_pages > self.capacity and self.ordinary:
                key, _ = self.ordinary.popitem(last=False)
                if key.startswith("prefetch:"):
                    self.prefetch_evictions += 1
        else:
            entry.state = "ready"
        self._check_invariant()
        return True

    def admit(self, request_id: str) -> bool:
        if self.policy == "leased":
            entry = self.prefetches.get(request_id)
            if entry is None or entry.state != "ready":
                return False
            entry.state = "admitted"
            self._check_invariant()
            return True
        return "prefetch:" + request_id in self.ordinary

    def finish_admission(self, request_id: str) -> bool:
        if self.policy != "leased":
            return False
        entry = self.prefetches.get(request_id)
        if entry is None or entry.state != "admitted":
            return False
        del self.prefetches[request_id]
        self._check_invariant()
        return True

    def cancel(self, request_id: str) -> bool:
        entry = self.prefetches.pop(request_id, None)
        if entry is not None:
            self._check_invariant()
            return True
        return self.ordinary.pop("prefetch:" + request_id, None) is not None

    def insert_ordinary(self, key: str, pages: int) -> bool:
        if pages <= 0 or pages > self.capacity:
            return False
        if key in self.ordinary:
            old = self.ordinary.pop(key)
            if old == pages:
                self.ordinary[key] = old
                self._check_invariant()
                return True
        if not self._make_room(pages):
            self._check_invariant()
            return False
        self.ordinary[key] = pages
        self._check_invariant()
        return True

    def _check_invariant(self) -> None:
        assert self.used_pages <= self.capacity, (self.used_pages, self.capacity)
        if self.policy == "leased":
            assert all(e.state in {"prefetching", "ready", "admitted"}
                       for e in self.prefetches.values())


def counterexample(policy: str) -> dict:
    """A 2-page tier: B's read competes with completed A before A is admitted."""
    tier = HostTier(capacity_pages=2, policy=policy)
    accepted_a = tier.start_prefetch("A", 2)
    tier.complete_prefetch("A")
    accepted_b = tier.start_prefetch("B", 2)
    if accepted_b:
        tier.complete_prefetch("B")
    a_admitted = tier.admit("A")
    return {
        "policy": policy,
        "A_prefetch_accepted": accepted_a,
        "B_prefetch_accepted": accepted_b,
        "A_admission_hit": a_admitted,
        "declined_prefetches": tier.prefetch_declines,
        "prefetched_pages_evicted": tier.prefetch_evictions,
        "tier_pages_used": tier.used_pages,
    }


if __name__ == "__main__":
    import json
    print(json.dumps({p: counterexample(p) for p in ("unreserved", "leased")}, indent=2))
