# Preventing L3 prefetch eviction before admission

**Status:** CPU reference model for a suspected SGLang HiCache lifetime bug. It is not a patch to SGLang, not a GPU reproduction, and not a novelty claim.

## Why this is the strongest concrete lead so far

SGLang issue [#49221](https://github.com/sgl-project/sglang/issues/49221) reports a specific failure mode: host pages fetched from Mooncake L3 can be evicted from HiCache L2 before a request is admitted to use them. The issue's reproducer reports 188,416 cached tokens when 32 requests are replayed serially, versus 64,768 at concurrency 16, while the admission-shortfall counter rises by 88,320 tokens. That is a 65.6% reduction in observed cached tokens in the burst test. The issue explicitly warns that the shortfall counter includes retries, so it is not a count of unique recomputed tokens. Its suspected root cause is a lifetime gap between prefetch completion and admission.

**Correction after checking the live GitHub records:** the issue is still marked Open, but it does have an exact fix already under review. PR [#49226](https://github.com/sgl-project/sglang/pull/49226), “retain prefetched host pages until admission,” is linked from the issue and implements the central lease/retention invariant, including cleanup and capacity-pressure handling. It reports H20 measurements with 16-concurrent hit rate improving from 36.20% to 96.52% and shortfall falling from 82,432 to zero; at concurrency 32, it reports hit rate improving from 66.36% to 96.52%. These are contributor-reported benchmark results, not independently reproduced here. The PR is open and not mergeable at the checked snapshot, with lint/CI and integration work outstanding.

A second open PR, [#51409](https://github.com/sgl-project/sglang/pull/51409), broadens this to capacity deferrals and prefill/decode paths, and incorporates retention commits from #49226. Its author reports 12/12 and 16/16 L3 hits for `wait_complete` after retention in two GPU runs; timeout-policy hit rates improved but remained below 100%, with remaining misses attributed to explicit deadline traces. The PR itself says the overlap/dependency strategy needs reconciliation before merge. These are contributor-reported functional results, not production measurements or independently reproduced results. This makes a separate upstream implementation duplicative. **My earlier statement that there was no linked PR was wrong.** The local model below is useful only as a small explanatory state-machine sketch; it is not a new solution or evidence of novelty.

## Proposed invariant

A completed L3 prefetch that is reported as reusable must remain available until one of three events: its matching request is admitted, the request attempt is canceled, or its bounded lease expires. The lease must be request-attempt scoped so a retry cannot consume another attempt's pages.

A bounded implementation needs both protection and admission control:

1. Count a prefetch reservation against L2 capacity before allocating/fetching its destination pages.
2. Protect completed pages from ordinary LRU eviction while their reservation is live.
3. On successful request admission, atomically consume/release the temporary reservation according to the H2D/load-back ownership path.
4. On cancel, timeout, or failed admission, release the reservation and its page references.
5. If capacity is unavailable, decline or shorten the prefetch. Do not claim those pages as an expected hit. Preserve the demand-load fallback.

Merely pinning every completed read would risk deadlock or starvation under pressure. The reservation budget must be bounded, and a prefetch must be declined when the admitted plus reserved page count would exceed capacity.

## Executable model

`reservation_model.py` compares an unreserved policy with a leased policy in a two-page host tier. The event schedule is: A prefetches two pages, A completes, B competes for two pages, then A is admitted.

- **Unreserved LRU:** B's completed prefetch evicts A. A misses at admission; one already-fetched prefix must be fetched again.
- **Lease:** A's pages stay available. B is declined before overcommitting the tier. A hits at admission.

The model also checks that ordinary cache pressure cannot evict a live lease, that cancellation releases capacity, admission waits for transfer completion, and used pages never exceed capacity. Five focused CPU tests pass.

## Limits and status

This model does not model SGLang's tree-node locking, host-pool allocator, Mooncake transfer lifecycle, PP rank coordination, or asynchronous cancellation, and it is redundant with the design now present in #49226. The upstream fix already has benchmark evidence from its author; we have not reproduced it on the issue's pinned snapshot or independently validated its reported gains. No GPU was available in this workspace, so this result does not support a claim of a new breakthrough, production impact, or profitability. The technically appropriate path is to track the existing PRs and let their maintainers reconcile implementation overlap and finish validation, rather than submit a duplicate fix.
