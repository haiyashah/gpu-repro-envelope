# Experiment plan

## Question

With the data, starting weights, batch order, optimizer, and deterministic PyTorch settings fixed, are training trajectory differences across GPUs larger than same-device repeat variation? If so, do they produce held-out prediction changes?

## Unit of analysis

One seed × one device × one independent process run. The planned comparison is three seeds with three runs per seed on each available device. A device comparison is valid only when dataset and initial-weight hashes match.

## Controls

- Synthetic CPU-generated dataset; no external data or downloads.
- Initialization generated on CPU and transferred to GPU.
- Fixed minibatch index sequence generated on CPU.
- FP32; TF32 disabled; deterministic PyTorch algorithms enabled; fixed cuBLAS workspace configuration.
- Same PyTorch/CUDA container tag across GPU types when available. Record actual runtime versions and host drivers. If software versions differ, describe this as an environment comparison rather than attributing the effect solely to the GPU.
- Same-device repeats run in separate processes. If a GPU is unavailable for enough repeats, report the reduced design.

## Outcomes

Primary: held-out prediction disagreement and task accuracy. Secondary: checkpoint-wise parameter L2/relative-L2/max-absolute difference, held-out logits RMS difference, loss, and exact checkpoint hashes. Record elapsed time as context, not as a performance benchmark.

The first checkpoint with a bitwise difference is diagnostic only. Weight divergence by itself is not evidence of a behaviorally important change.

## Decision rule

Compare cross-device differences against the empirical distribution of same-device replicate pairs at matching seeds and steps. Report all individual runs and all seeds. With only three seeds, use descriptive comparisons and do not claim a population-level significance estimate.

## Provenance

Preserve source revision, exact command, runtime fingerprint, seed, dataset and initial-weight hashes, raw JSON, checkpoint file, failed runs, and exclusions. Never store API keys, tokens, or full environment dumps.
