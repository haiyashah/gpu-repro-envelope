# Grammar-conditioned numerical ambiguity: exploratory protocol

## Motivation and literature boundary

Recent work has already shown that greedy LLM output can change across precision modes and evaluated margin-triggered FP32 `lm_head` recomputation. The proposed study does not claim that phenomenon or that intervention as new. See [Du et al. (2026), arXiv:2609.26621](https://arxiv.org/abs/2609.26621).

Grammar-constrained decoding masks vocabulary tokens that cannot legally continue a structured output. XGrammar and later work focus on efficient grammar preprocessing and mask computation; grammar masks are a runtime part of structured-output serving. This pilot asks whether precision fallback should measure ambiguity over the full vocabulary or only over the legal next-token set supplied by the grammar. A focused search did not identify a paper testing this precise interaction. That search is not exhaustive, so no novelty claim will be made without further review.

Related foundations include [Flexible and Efficient Grammar-Constrained Decoding (ICML 2025)](https://proceedings.mlr.press/v267/park25l.html) and [NVIDIA's grammar-constrained Bash generation evaluation](https://developer.nvidia.com/blog/improving-bash-generation-in-small-language-models-with-grammar-constrained-decoding/).

## Hypothesis

The precision-sensitive decision at a constrained decoding step depends on the logit margin among grammar-legal candidates, not on the margin between the top two logits over the entire vocabulary. Therefore, a full-vocabulary margin gate may trigger avoidable FP32 recomputation when close logits belong to tokens the grammar forbids. A legal-set gate could reduce fallback frequency while retaining the ability to detect BF16-versus-FP32 changes to the constrained argmax.

## Measurements

For each constrained JSON/tool-call generation step, record:

- size and fraction of grammar-legal token IDs;
- BF16 top-two margin over the full vocabulary and the legal set;
- BF16 argmax, FP32 argmax, and BF16-body/FP32-legal-head rerank token over the legal set;
- threshold-trigger counts for both gates at identical thresholds;
- whether each gate catches a BF16-to-FP32 legal-argmax flip;
- JSON validity and task-level argument accuracy;
- count of FP32 head rows evaluated and a separately timed microbenchmark if the probe is stable.

## Falsifiable outcomes

- The hypothesis is not supported if full-vocabulary and legal-set gates trigger at similar rates or if the legal-set gate misses materially more legal-argmax changes.
- The hypothesis receives preliminary support if legal-set gating reduces selected rerank work while preserving legal-argmax agreement and structured-task accuracy on multiple prompts.
- Even a positive result is a small single-GPU pilot. A production claim would require larger models, real serving kernels, multiple schemas and prompt distributions, repeated timed trials, and comparisons with optimized full precision and BF16 baselines.

## Planned probe

Use `Qwen/Qwen2.5-0.5B-Instruct` on short schema-constrained JSON tool-call prompts. Generate constrained FP32 continuations, then score each prefix under FP32 and BF16. Obtain each prefix's legal token set from `lm-format-enforcer`. Compare full-vocabulary and legal-set margin gates, then test a candidate-only FP32 vocabulary-head rerank over grammar-legal token rows using BF16 body states. Publish the observed results, including null or adverse outcomes, with the complete code and hardware/software fingerprint.
