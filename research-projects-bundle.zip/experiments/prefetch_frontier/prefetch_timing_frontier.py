"""Explore when return-time prediction is worth its KV residency cost.

This is an analytical Monte Carlo model, not an engine benchmark. A prefetch
takes R seconds. If issued at s, it completes at s+R. A return during transfer
waits only for the remaining transfer; a completed copy occupies fast memory
until resume and incurs a configurable shadow cost.

The model deliberately omits queue interference and multiple objects. Its use
is to expose the decision boundary and the assumptions that a systems benchmark
must measure, not to predict production speedups.
"""
from __future__ import annotations
import json
import math
import random
from bisect import bisect_right
from pathlib import Path

SEED = 20261127
N = 200_000


def traces(seed: int = SEED, n: int = N) -> dict[str, list[float]]:
    rng = random.Random(seed)
    return {
        # Toy distributions chosen to represent qualitatively different hazards.
        "exponential_short": [rng.expovariate(1 / 1.0) for _ in range(n)],
        "lognormal_heavy_tail": [rng.lognormvariate(math.log(6.0), 1.3) for _ in range(n)],
        "bimodal_fast_or_slow": [
            (rng.expovariate(1 / 0.35) if rng.random() < 0.8
             else rng.expovariate(1 / 24.0)) for _ in range(n)
        ],
    }


def utility(ordered: list[float], prefix: list[float], completion_time: float,
            read_s: float, kv_gib: float,
            rent_s_per_gib_s: float) -> tuple[float, float, float]:
    """Return mean net value, hit probability, and residency GiB-seconds.

    completion_time includes transfer duration. Net value is seconds of avoided
    slow-tier wait minus a shadow price for fast-tier residency.
    """
    count = len(ordered)

    def expected_excess(threshold: float) -> float:
        i = bisect_right(ordered, threshold)
        n_tail = count - i
        return (prefix[-1] - prefix[i] - n_tail * threshold) / count

    issue_time = completion_time - read_s
    saved = expected_excess(issue_time) - expected_excess(completion_time)
    residency = expected_excess(completion_time) * kv_gib
    i = bisect_right(ordered, completion_time)
    hits = count - i
    rent = residency * rent_s_per_gib_s
    return saved - rent, hits / count, residency


def best_time(delays: list[float], read_s: float, kv_gib: float,
              rent_s_per_gib_s: float) -> dict:
    # The optimum lies on an empirical duration grid shifted by read latency.
    ordered = sorted(delays)
    prefix = [0.0]
    for value in ordered:
        prefix.append(prefix[-1] + value)
    candidates = sorted({read_s, *(max(read_s, ordered[int((len(ordered) - 1) * q)] + read_s)
                                for q in (i / 1000 for i in range(1, 1000))),
                         ordered[-1] + read_s})
    scored = [(utility(ordered, prefix, t, read_s, kv_gib, rent_s_per_gib_s), t)
              for t in candidates]
    (net, hit, resident), t = max(scored, key=lambda x: x[0][0])
    return {"completion_time_s": t, "issue_time_s": t - read_s, "net_value_s": net,
            "hit_probability": hit, "mean_residency_gib_s": resident}


def run() -> dict:
    read_times = (0.05, 0.2, 1.0)
    rent_prices = (0.001, 0.01, 0.1, 0.5)
    kv_gib = 1.0
    output = {"metadata": {
        "seed": SEED, "samples_per_distribution": N,
        "kv_context_gib": kv_gib,
        "read_latency_s": list(read_times),
        "residency_shadow_price_s_per_gib_s": list(rent_prices),
        "interpretation": "synthetic analytical model; not production traces or GPU results",
    }, "results": []}
    for name, delays in traces().items():
        row = {"distribution": name,
               "mean_delay_s": sum(delays) / len(delays),
               "p50_delay_s": sorted(delays)[len(delays) // 2],
               "p90_delay_s": sorted(delays)[int(.9 * len(delays))]}
        for read_s in read_times:
            for rent in rent_prices:
                opt = best_time(delays, read_s, kv_gib, rent)
                median_t = max(read_s, row["p50_delay_s"])
                ordered = sorted(delays)
                prefix = [0.0]
                for value in ordered:
                    prefix.append(prefix[-1] + value)
                med_net, med_hit, med_res = utility(
                    ordered, prefix, median_t, read_s, kv_gib, rent)
                row.setdefault("conditions", []).append({
                    "read_latency_s": read_s,
                    "rent_price_s_per_gib_s": rent,
                    "optimal": opt,
                    "median_timing": {"completion_time_s": median_t,
                                      "net_value_s": med_net,
                                      "hit_probability": med_hit,
                                      "mean_residency_gib_s": med_res},
                    "reactive_net_value_s": 0.0,
                })
        output["results"].append(row)
    return output


if __name__ == "__main__":
    result = run()
    out = Path(__file__).with_name("results.json")
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {out}")
