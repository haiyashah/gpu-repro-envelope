# When should an agent KV prefetch start?

**Status:** CPU-only analytical simulation. This is a decision-rule prototype, not a GPU or engine benchmark, and not a novelty claim.

## Research question

Recent agent-serving work reaches different conclusions about predicting tool-return times to prefetch KV. [TripleKV](https://arxiv.org/abs/2611.25112) reports large P95 TTFT wins by predicting a tool's completion and moving the known-next KV from SSD to DRAM. A separate [analysis of 743,819 TraceLab tool calls](https://vitalynetwork.com/blog/tool-pauses-kv-cache/) reports that return-time prediction did not pay on its measured setup, where the DRAM tier and store path dominated. A [vLLM RFC](https://github.com/vllm-project/vllm/issues/57103)'s single-L20 measurements found request-free prefetch useful but sensitive to lead time, with no timing predictor needed in its tested regime. These results do not establish a contradiction: they use different memory tiers, costs, and workloads. They do expose the missing practical question: **what transfer and capacity conditions make a timing predictor valuable?**

## Decision rule

Let `D` be the random tool-wait duration, `R` the slow-tier read time, `s` the prefetch issue time after the pause starts, `v` the context size, and `rho` the fast-tier residency shadow price in seconds of latency cost per GiB-second. Expected net value is

`U(s) = E[min(max(D - s, 0), R)] - rho * v * E[max(D - s - R, 0)]`.

The first term is the slow-tier delay hidden by prefetch. The second prices the period when the completed copy occupies fast memory before the agent returns. For a smooth return-time survival function `S`, an interior optimum satisfies

`S(s) / S(s + R) = 1 + rho * v`.

Equivalently, the integrated hazard across one transfer window is `ln(1 + rho*v)`. This is a cost-sensitive timing rule: high transfer cost and cheap capacity favor starting earlier; expensive capacity favors waiting or skipping prefetch. It also explains why a point forecast such as the median is not generally the right scheduling target.

## Experiment

`prefetch_timing_frontier.py` compares the best empirical issue time against a median-timed prefetch and reactive load-on-return. It uses 200,000 samples each from three explicitly synthetic distributions: short exponential waits, heavy-tailed lognormal waits, and a fast/slow bimodal mixture. It sweeps slow-tier read time `{0.05, 0.2, 1.0}` seconds and residency shadow price `{0.001, 0.01, 0.1, 0.5}` seconds per GiB-second for a 1 GiB context. Seed: `20261127`.

Selected results (mean avoided-read seconds after residency price; a value at or below zero means reactive loading is at least as good in this model):

| Return distribution | Read time | Residency price | Best timing value | Median-timed value | Best completion time |
|---|---:|---:|---:|---:|---:|
| Short exponential | 0.20 s | 0.01 | 0.1731 s | 0.1057 s | 0.20 s |
| Heavy-tailed lognormal | 0.20 s | 0.01 | 0.0632 s | 0.0058 s | 0.31 s |
| Heavy-tailed lognormal | 0.20 s | 0.10 | 0.0000 s | -0.8513 s | skip |
| Fast/slow mixture | 0.20 s | 0.01 | 0.1128 s | 0.0730 s | 0.20 s |
| Fast/slow mixture | 0.20 s | 0.10 | 0.0000 s | -0.3601 s | skip |

The strongest simulated effect is not a speedup claim. It is a policy failure mode: median-timing can over-prefetch under high residency cost, while a cost-aware rule chooses no prefetch. Under low occupancy cost, an early transfer can beat median-timing because a heavy-tailed return distribution gives an early completed read a long chance to hide latency.

## What this establishes, and what it does not

The script establishes this decision frontier for the stated mathematical model and fixed synthetic samples. It does not model multi-session capacity explicitly, link contention, correlated arrivals, tool-result-dependent context changes, cache eviction, HBM/DRAM/SSD hierarchy, or online estimation error. The residency shadow price is a parameter, not a measured conversion from a serving fleet. Therefore none of the numbers should be quoted as a serving-engine speedup.

The next serious experiment is to fit this rule on a public trace and measure it in a real offload engine while sweeping DRAM capacity and read bandwidth. The comparison must report both TTFT and foreground interference, plus prediction calibration, and include pause-triggered, median-predicted, and oracle policies. A live GPU is required for that step. No GPU was available for this run and no cloud instance was started.
