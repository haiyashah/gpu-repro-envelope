# KV-cache partitioning conformance prototype

**Status:** CPU-only reference harness; not yet connected to a serving engine.

## Research finding

The broad “KV-cache partition conformance suite” gap is already being worked on upstream: vLLM issue [#53194](https://github.com/vllm-project/vllm/issues/53194) describes it, and its linked test work [#53769](https://github.com/vllm-project/vllm/pull/53769) covers dimensions × cache tiers plus a connector registry gate. This prototype overlaps that work; it is not a novel discovery.

The narrower gap found in the audit is a semantic input dimension that generic key-partition coverage can miss: `prompt_is_token_ids`, the per-position selector for mixed token-ID / supplied-embedding prompts. The vLLM report in issue [#56655](https://github.com/vllm-project/vllm/issues/56655) describes a correctness failure when token IDs and embedding tensor match but this mask differs. In its controlled Qwen3-0.6B test, the wrong warm-cache request reused 32 tokens and produced the prior request's output; cold runs produced different output. The issue says the then-current #53769 suite did not cover this mask dimension. This is a concrete example of why cache-key test matrices need to enumerate *effective model inputs*, not only familiar tenancy and adapter fields.

The specific Harmony `cache_salt` continuation defect is also already documented and fixed upstream in vLLM 0.30.0. See the [security advisory](https://github.com/vllm-project/vllm/security/advisories/GHSA-935w-9g4m-p28p).

## What I implemented

`bench/cache_partition_conformance.py` is a small, framework-neutral executable prototype, not an upstream integration. The auditor requires a same-identity hit and a one-dimension-different miss for each declared entrypoint × tier × identity-dimension path. It also rejects probes outside declared coverage and can reject uncovered connectors supplied by a runtime registry. The fixture `experiments/fixtures/prompt_mask_partition.json` shows how an adapter can declare the mixed-prompt routing mask as an identity dimension.

The checks use observed reuse behavior, not private hash tuple layout. A `Probe` records the warm and probe identities so the auditor verifies that a “different tenant” probe really changes only the claimed field. The key builder is an example canonical encoding; production adapters should not compare their internal hash bytes to it.

## Results

Eight tests cover a passing matrix, JSON adapter ingestion, and five seeded test faults:

| Injected condition | Expected detector | Result |
|---|---|---|
| Salt dropped on a tool-continuation path | Cross-tenant request hits a warmed prefix | Rejected |
| Prefix caching disabled for every request | Same-tenant positive control misses | Rejected |
| Probe is labeled “different” but identity is unchanged | Identity/control mismatch | Rejected |
| A connector appears in the discovered registry without a test | Coverage gate | Rejected |
| A probe arrives from an undeclared endpoint | Coverage drift | Rejected |

The focused suite and the existing KV protocol checks pass: **23 tests** in total. The JSON CLI also accepts the clean fixture. These are deterministic CPU tests of the auditor and its seeded fixtures. They do not establish that any particular serving-engine endpoint is currently vulnerable or fixed; the GPU reproduction described in #56655 is upstream authors' evidence, not a run performed here.

## Next validation step

The useful next step is an adapter test that drives the mixed token-ID / prompt-embedding mask cases through a real engine, captures cold and warm outputs plus cached-token counts, and verifies both output equivalence to the cold baseline and the expected cache miss. Re-run it against current upstream, because #56655's measurements are tied to the revision it reports. A GPU is required for this engine-level reproduction, not for the auditor itself.

This is a scoped testing prototype around a publicly reported open bug, not a new cache-isolation principle, independent reproduction, or completed upstream contribution.
