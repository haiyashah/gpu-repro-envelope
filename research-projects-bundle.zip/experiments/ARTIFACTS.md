# Frozen experiment definition

## Pilot artifact availability

The three A40 run JSON files and their `.pt` checkpoints were generated in the RunPod workspace. The repository currently contains the transcribed final metrics in `PILOT_RESULTS.md` and `pilot-summary.json`, not the full raw run records or checkpoints. The pilot should be treated as a preliminary report until those raw files are copied into the repository.

## Workload

- Task: two-class concentric-ring classification generated on CPU from a fixed seed.
- Model: `Linear(2,64) -> GELU -> Linear(64,64) -> GELU -> Linear(64,2)`.
- Optimizer: AdamW, learning rate `0.003`, weight decay `0.0001`.
- Arithmetic: FP32, TF32 disabled, deterministic algorithms enabled, cuBLAS workspace set to `:4096:8` before CUDA initialization.
- Data order: minibatch indices generated once from a seeded CPU generator, with no data loader or worker processes.
- Controls: same initial weights and data hashes are mandatory. Run at least three repetitions per device/seed and at least five seeds if GPU budget allows.
- Metrics: exact parameter hash at checkpoints; parameter L2 and relative L2 distance; max absolute parameter delta; held-out logit RMS; prediction disagreement; test loss/accuracy; elapsed training time.

## Comparison design

First test same-device repeatability. Then compare GPU architectures while holding PyTorch and CUDA versions constant where RunPod images allow. If the software stack differs, treat it as a separate environment factor and do not attribute the whole effect to silicon. Use `bench/compare_runs.py` only for pairs with identical dataset and initial-weight hashes.

The first non-bitwise-equal checkpoint is a diagnostic, not the primary outcome. Primary behavior outcomes are held-out prediction disagreement and task metrics. Numeric differences alone do not establish a practically important effect.

## Run commands

```bash
python bench/train_path.py --seed 7 --steps 500 --output runs/a100-seed7-r1.json
python bench/compare_runs.py runs/a100-seed7-r1.json runs/a100-seed7-r2.json --output runs/same-device.json
```

Keep each JSON and its same-basename `.pt` file together. The `.pt` file contains only synthetic data hashes, parameter snapshots, and synthetic held-out logits.
