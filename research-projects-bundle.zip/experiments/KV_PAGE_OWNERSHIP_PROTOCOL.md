# KV page ownership: bounded race checker and GPU validation plan

## Why this question

Cloudflare disclosed that an over-length prefill request could be rejected, replaced by a placeholder, and still marked complete. Decode then attended over old KV pages because the receiving side trusted completion without confirming the full transfer. A separate class of races arises when an asynchronous transfer can still write to a page after its request is aborted and the page is reassigned. These are correctness and tenant-isolation failures in the memory-management path of inference.

The report is public and its incident fixes have landed. This project does **not** claim to discover the incident or the general stale-KV risk. The narrower engineering question is whether a reusable, architecture-independent lease check can fail closed across both incomplete handoffs and late writes, and what its latency/memory cost is on a serving path.

## Implemented first slice

`bench/kv_page_model_check.py` and `bench/kv_protocol_state_space.py` enumerate interleavings for a one-page, two-request model. The state-space explorer compares:

1. immediate page reuse after abort versus quarantine until all remote writers drain;
2. trusting a transfer-complete flag versus requiring admission success and an exact token/page count;
3. checking the page's active lease and content provenance at the attention-read boundary;
4. accepting an untagged acknowledgement for a reused room ID versus rejecting acknowledgements from an old generation.
5. releasing a device page on timeout versus quarantining it until a drain ACK or transport fence.

It emits counterexample traces for unsafe protocol combinations and asserts that the fail-closed policies prevent cross-request reads within the enumerated model. The timeout experiment reaches a foreign read when the code releases A's page after its deadline, B writes and verifies its own payload, then A's already-posted write lands before B decodes. The quarantine policy prevents reuse and fails closed. Thirteen unit tests pass across the model and the reference allocator.

This is a bounded control-plane model, not a GPU result, not a proof about SGLang/vLLM, and not a discovery of the public incident. It deliberately separates the rejection/short-transfer failure from the asynchronous late-writer failure: either one can produce foreign KV, and a mitigation for one class does not automatically close the other.

## Upstream audit finding

At SGLang commit `ce4518faada6e7fc7d9fc8590304caec7b0c330f`, `DecodeTransferQueue.resolve_deferred_releases` releases device destinations at the configured deadline even when the drain ACK is absent. The code comments that no proof exists that the remote writer stopped, and `test_releases_on_timeout_without_ack` asserts that the page/metadata slot is freed. This is an explicitly known open safety tradeoff in upstream, not a newly discovered bug. The model's counterexample instantiates the unsafe ordering. Reference source: [`decode.py`](https://github.com/sgl-project/sglang/blob/ce4518faada6e7fc7d9fc8590304caec7b0c330f/python/sglang/srt/disaggregation/decode.py) and [`test_deferred_decode_kv_release.py`](https://github.com/sgl-project/sglang/blob/ce4518faada6e7fc7d9fc8590304caec7b0c330f/test/registered/unit/disaggregation/test_deferred_decode_kv_release.py).

## Fail-closed reference allocator

`src/kv_lease_pool.py` implements a minimal page lease API. A timeout moves pages to `QUARANTINED`; allocation cannot reuse them. Only all expected generation-matched drain ACKs plus zero locally tracked writes, or an explicit transport-fence confirmation, releases pages. This trades capacity for isolation when the system cannot prove a remote write stopped. The integration still has to make that fence signal trustworthy and coordinate quarantine consistently across attention-parallel ranks.

## Candidate invariant

For every attention read of page `p` by request lease `L`, the page must be committed to `L`, every required KV byte must have been transferred for the current incarnation of `p`, and no asynchronous writer from an earlier lease may still target `p`. A completion flag alone is insufficient. A page ownership tag must be coupled to the bytes it authenticates or protected by a transfer-drain protocol; merely updating allocator metadata on reuse cannot detect an old DMA write that arrives later. Every acknowledgement must also identify the request generation and sender rank, so a delayed response cannot satisfy a newer lease's drain barrier.

## GPU experiment once the H100 notebook is reachable

- Integrate the guard at one concrete KV page read path in a pinned SGLang release, retaining the public incident reproducer's safe boundary conditions.
- Exercise ordinary requests, oversized/rejected prefills, client abort during transfer, delayed completion, page reuse, and concurrent decode.
- Use unique synthetic canary strings per request. Assert that no response contains another request's canary and that every read either owns a fully committed lease or fails closed.
- Compare baseline, upstream fixes only, and the read-time lease guard. Measure p50/p95/p99 latency, throughput, memory overhead, guard false rejects, and transfer-drain time over repeated randomized schedules.
- Keep the benchmark local to the isolated instance. Do not probe third-party services or real user data.

## Stop/go criteria

The project should proceed as a systems contribution only if a reproducible test finds a path not already closed by the pinned upstream release, or if the guard provides materially stronger coverage with negligible cost. A clean run on the patched release is useful validation but is not a discovery. Do not publish novelty language without a broader literature and upstream-code audit.

## Evidence and boundary

- Cloudflare's incident report identifies the undersized prefill pool, placeholder path, incomplete transfer assumption, and stale KV exposure. It also describes page-level tags as a stronger read-time defense, but says its prototype was architecture-specific and was disabled after reliability issues.
- SGLang published the coordinated fix and subsequent cache-lifetime hardening.
- The protocol must account for stale acknowledgements as well as stale writes. SGLang documents generation-tagged abort acknowledgements because room IDs can be reused.
- This first slice only checks a small abstract event model. It has no CUDA, serving-engine integration, latency measurement, or adversarial security evaluation yet.
