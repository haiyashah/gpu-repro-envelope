# Prior work and the boundary of this experiment

This is a focused replication/measurement project, not a claim that hardware affects reproducibility for the first time.

## Established

- PyTorch explicitly warns that reproducibility is not guaranteed across releases or platforms, including GPU versus CPU, even with the same seed. Its controls target repeatability for a specific platform and release: [PyTorch randomness notes](https://pytorch.org/docs/stable/notes/randomness.html).
- Deterministic kernels and tooling have been studied as sources of training randomness, including their substantial performance costs across hardware: [Pham et al., MLSys 2022](https://proceedings.mlsys.org/paper_files/paper/2022/hash/427e0e886ebf87538afdf0badb805b7f-Abstract.html).
- Floating-point non-associativity can affect HPC and deep-learning reliability, and PyTorch deterministic options have been evaluated: [Shanmugavelu et al., SC-W 2024](https://arxiv.org/abs/2408.05148).
- A 2026 *Nature Machine Intelligence* study reports very large-scale evidence that deep-learning training can be sensitive to small perturbations and initial conditions: [Fractal basin geometry and the limits to predictability and reproducibility in deep learning](https://www.nature.com/articles/s42256-026-01336-3).

## Narrow empirical question here

The contribution sought is a compact, fully auditable paired experiment that decomposes *same-device repeat noise* from *cross-device trajectory drift* under one fixed, deterministic FP32 training recipe, then checks if drift crosses into held-out prediction disagreement. This is not the same as proving cross-hardware reproducibility is generally bad, and is not presented as an established literature gap until a more complete search is done.

The decision to publish a result depends on measured runs. If only one GPU architecture can be rented, the project will report the same-device reproducibility control and state plainly that the cross-device question remains unanswered.
