# Timeout is not a drain proof

## Formal statement

At timeout, suppose decode has received no positive drain acknowledgement. Consider two worlds with identical receiver-visible history:

- **World D:** all posted writes have landed, but the acknowledgment was lost.
- **World P:** at least one posted write is still delayed and can land later.

If the protocol's only new input is the elapsed deadline, decode must make the same release decision in both worlds. Releasing is unsafe in P because the old writer can land in a newly leased page. Holding is safe in both worlds, but in D the page may remain unavailable forever because the lost acknowledgment cannot arrive. Therefore, a timeout alone cannot guarantee both isolation and reclamation.

The protocol needs one of three things: a trustworthy positive transport fence/drain signal, a hard upper bound on every posted write that the transport enforces, or indefinite quarantine with explicit capacity loss. A longer timer changes the probability of the delayed-world case only if a latency distribution is known; it does not prove it impossible.

## Executable check

`bench/timeout_safety_liveness.py` evaluates the two indistinguishable worlds against `reuse_now` and `hold_forever`. The assertions in `tests/test_timeout_safety_liveness.py` confirm that no timeout-only policy satisfies both safety and page reclamation in both worlds.

This is a small indistinguishability argument, not an empirical rate measurement or a new discovery claim. Its value is a precise design gate: a production fix must name and test the extra evidence that turns an unsafe timeout into a safe release.
