# A40 same-device pilot

## What ran

Three separate processes trained the same seed-7 synthetic concentric-rings classifier for 500 optimizer steps on one NVIDIA A40. The experiment used PyTorch 2.8.0 with CUDA 12.8.1 and driver 595.112.07. It enabled deterministic algorithms, disabled TF32, fixed the CPU-generated training and test tensors, fixed initialization, and precomputed minibatch order on CPU.

## Observed final checkpoint

| Run | GPU | Seed | Steps | Test accuracy | Test loss | Final weights SHA-256 |
|---|---|---:|---:|---:|---:|---|
| seed7-r1 | A40 | 7 | 500 | 0.9931640625 | 0.014963345602154732 | `736cdf084fb631d8d53b312b6149eaef7a00e586f9f381ca707e277f22ab7eb8` |
| seed7-r2 | A40 | 7 | 500 | 0.9931640625 | 0.014963345602154732 | `736cdf084fb631d8d53b312b6149eaef7a00e586f9f381ca707e277f22ab7eb8` |
| seed7-r3 | A40 | 7 | 500 | 0.9931640625 | 0.014963345602154732 | `736cdf084fb631d8d53b312b6149eaef7a00e586f9f381ca707e277f22ab7eb8` |

The SHA-256 is over the flattened final parameter tensor. The matching hashes indicate bitwise-identical final parameters among these three same-device runs. Each run classified 2,034 of 2,048 synthetic test examples correctly.

## Interpretation

This is a narrow reproducibility check for one A40, one software stack, one synthetic task, and one seed. It shows that this short, deterministic FP32 workload was repeatable in the observed environment. It does **not** show that cross-GPU training diverges, that deterministic settings always guarantee identical outputs, or that the result generalizes to other seeds, architectures, mixed precision, distributed training, or production workloads. No H100 run was completed, so there is no cross-GPU comparison and no finding about cross-GPU trajectory drift.

The original per-run JSON and `.pt` checkpoint files remain in the RunPod A40 workspace. This summary records their observed final fields; the full raw artifacts have not yet been copied into this repository.
