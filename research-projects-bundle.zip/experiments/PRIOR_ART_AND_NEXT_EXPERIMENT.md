# Prior-art check: KV-page integrity

**Checked:** 2026-11-27  
**Decision:** Do not present the current KV timeout/quarantine work as a novel result.

## What the local work establishes

The local model checks that a timeout without a drain acknowledgment cannot distinguish a drained transfer whose acknowledgment was lost from a transfer that can still write later. It tests that immediate reuse can violate isolation, while indefinite quarantine can sacrifice reclamation. The Python pool implements fail-closed quarantine and releases only after its caller reports drain or transport-fence evidence.

The 15 local unit/model-check tests pass. This verifies the implementation's bounded model and state transitions. It is not an RDMA/GPU experiment, a proof of a transport API's fencing semantics, or a novel theorem.

## Prior art found

| Work | Overlap with this project | Consequence |
|---|---|---|
| Zhang et al., *Towards Verifiable LLM Infra* (Nov. 2026) | Models the same timeout indistinguishability tradeoff, uses versioned page tickets and `DRAINING`/`QUARANTINED`, tracks prefix-cache ownership, and reports GB200 RDMA reproductions in SGLang/vLLM. | The core idea and broader implementation are already published. A local two-world model is not a novelty claim. |
| Cloudflare, *Cross-request KV cache exposure…* (Oct. 2026) | Documents the production incident, deferred release, transfer checksums, page-generation tags, and the limitations of a model-specific read-time guard. | This establishes the problem and several candidate defenses. |
| Cheong et al., *KVGuard* (arXiv:2611.06138, Nov. 2026) | Adds KV-aware shadow metadata and checks across allocation, block tables, GPU lookups, and KV accesses; reports historical and newly found bugs in vLLM/SGLang. | A generic KV safety checker and kernel-boundary checks are also already covered. |

## What remains an engineering gap, not yet a contribution

Cloudflare reports that its early generation-tag guard was tied to particular attention backends and had reliability issues, and describes broad backend/model coverage as ongoing work. This is a concrete implementation gap. It is not evidence that a backend-independent design would be new: KVGuard already spans two engines and multiple kernel paths. Any proposed contribution needs a precise compatibility matrix and a reproduced failure that existing checks miss.

## Local execution limits

This workspace has no `nvidia-smi`, PyTorch, or Triton installation, and no visible CUDA device. The prior H100 JSON files are historical pilot results, not a GPU available to this run. I did not launch or charge for another cloud instance.

## Gate before claiming a new result

1. State a falsifiable failure mode that is not detected by the published PdLedger/veriserve or KVGuard checks.
2. Reproduce it against the exact relevant upstream revision, with a minimal test and a clean fixed-revision control.
3. Measure the fix on a GPU under a workload that exercises the affected backend, reporting correctness, p50/p99 latency, throughput, and memory.
4. Search again for the exact mechanism and result before writing a novelty or LinkedIn claim.

Until those gates pass, describe the local work only as a small independent executable illustration of the timeout tradeoff.
