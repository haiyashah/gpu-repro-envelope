# Content-bound identities for multimodal cache IDs

**Status:** Working ingress-side reference guard with eight passing unit tests and a CPU hashing microbenchmark. It is not integrated into vLLM and is not a novelty claim.

## The residual failure mode

vLLM allows a client to provide a multimodal `uuid`; when present, that UUID is used as the media cache identity instead of hashing the media bytes. The current security guidance puts uniqueness across callers on the client. If two distinct payloads reuse the same UUID, the later request can receive the earlier media's cached features. The issue report distinguishes a shape mismatch, which can crash the engine, from a same-shape collision, which can silently return a wrong answer.

The broad engine-containment work is already being pursued in [PR #63790](https://github.com/vllm-project/vllm/pull/63790). It checks feature/placeholder counts, aborts the affected request, and evicts poisoned cache entries across several layers. The PR is open. Reviewers raised concern about the breadth of the change while V1 is nearing deprecation. Its count check cannot identify equal-count, different-content collisions; [issue #55547](https://github.com/vllm-project/vllm/issues/55547) calls out this residual case and says a content hash is needed to detect it.

This is **not an unpublished problem**. The practical question answered here is narrower: can a gateway preserve useful repeated-media hits while refusing to treat a caller's UUID as proof that two payloads are identical?

## Implemented guard

`src/mm_cache_guard.py` derives a deterministic opaque media ID using HMAC-SHA256 over length-framed fields:

- tenant ID, so distinct tenants do not share media-cache entries;
- immutable model and processor revisions, so model or preprocessing changes invalidate old IDs;
- modality and optional client media ID, separated as distinct domains;
- the exact media payload bytes, so equal-length content collisions produce different IDs.

A gateway can substitute this ID for a client-supplied media UUID before forwarding the request. This does not alter vLLM. It requires media bytes at the trusted ingress. A URL-fetching integration must enforce its own domain allowlist, size limits, and SSRF protections. The gateway secret must be shared across replicas that should share entries, and rotated deliberately when invalidation is wanted.

The module also derives a separate tenant-scoped `cache_salt` for vLLM's text-prefix cache. Separate HMAC domains keep media IDs and prefix salts from colliding. Together, the media ID scopes processor/encoder/prefix media keys, while the salt scopes ordinary text-prefix KV reuse. This follows vLLM's current guidance to scope both client-supplied identifiers at an authenticated gateway; the salt alone only isolates prefix-cache blocks.

The implementation intentionally fails closed if payload bytes are absent. Hashing the bytes on every request costs CPU time; the benchmark below measures this guard's hashing step only. It does not include HTTP parsing, base64 decode, URL retrieval, media decode, or model preprocessing.

## Verification

Nine focused CPU tests pass. They check deterministic same-payload reuse, different keys for same-length/different-content payloads, tenant separation for media IDs and prefix salts, model/processor revision invalidation, modality and client-ID domain separation, opacity, field-boundary ambiguity, and rejection of weak/missing inputs. The full repository test suite passes: 35 tests.

The HMAC-SHA256 microbenchmark ran 25 times per payload size on the current CPU workspace, in two invocations. One run's medians were:

| Payload | Median time | Effective throughput |
|---:|---:|---:|
| 1 KiB | 0.0081 ms | 121 MiB/s |
| 64 KiB | 0.0458 ms | 1,365 MiB/s |
| 1 MiB | 0.6207 ms | 1,611 MiB/s |
| 8 MiB | 4.9292 ms | 1,623 MiB/s |

The two 8 MiB medians were 4.93 ms and 5.15 ms. These are single-workspace CPU microbenchmarks, not an end-to-end serving result. They suggest that content binding is inexpensive enough to evaluate at a gateway, but no TTFT or cache-hit experiment has yet been run against a real vLLM deployment.

Run the guard tests and benchmark from the repository root:

```bash
python3 -m unittest tests/test_mm_cache_guard.py -v
python3 bench/mm_cache_identity_cost.py --repeats 25
```

## Evidence boundary and next experiment

The guard closes accidental or cross-tenant UUID aliasing only when it is applied to every media item before vLLM sees the request and the derived `cache_salt` is applied to every request. It does not validate vLLM's internal cache eviction behavior, protect clients that bypass the gateway, or prove a production-wide performance benefit. vLLM's default path without a caller UUID already hashes media bytes; this guard is for deployments that accept caller-supplied IDs and want tenant scoping plus content binding.

The meaningful next experiment is an integration test against a pinned vLLM revision: send payload A, then same-length payload B with the same client UUID, and compare cold outputs, warm outputs, cache hits, and gateway hash cost. Repeat across image, audio, and video requests and across two tenants. That experiment needs a runnable vLLM multimodal GPU environment, which is not present in this workspace.

## Sources

- [vLLM security guidance on multimodal UUIDs](https://docs.vllm.ai/en/latest/usage/security/): describes caller UUID behavior and cross-tenant collision risk.
- [vLLM issue #55547](https://github.com/vllm-project/vllm/issues/55547): reports silent wrong-answer reuse for same-shaped media with a colliding UUID.
- [vLLM PR #63790](https://github.com/vllm-project/vllm/pull/63790): open request-containment fix for feature/placeholder count mismatches and cache invalidation.
