#!/usr/bin/env python3
"""Probe grammar-conditioned numerical ambiguity on a pretrained chat LM.

This is an exploratory measurement, not a serving implementation. It compares
full-vocabulary and grammar-legal top-two BF16 margins on the same constrained
generation trajectories, then evaluates a legal-token-only FP32 lm_head rerank.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from lmformatenforcer import JsonSchemaParser
from lmformatenforcer.integrations.transformers import build_transformers_prefix_allowed_tokens_fn
from transformers import AutoModelForCausalLM, AutoTokenizer


MODEL = "Qwen/Qwen2.5-0.5B-Instruct"
TASKS = [
    ("Return a get_weather call for Paris.", "get_weather", {"city": "Paris"}, {"city": {"type": "string", "enum": ["Paris", "London", "Tokyo"]}}),
    ("Return a get_weather call for Tokyo.", "get_weather", {"city": "Tokyo"}, {"city": {"type": "string", "enum": ["Paris", "London", "Tokyo"]}}),
    ("Return a get_weather call for London.", "get_weather", {"city": "London"}, {"city": {"type": "string", "enum": ["Paris", "London", "Tokyo"]}}),
    ("Return a get_time call for UTC.", "get_time", {"timezone": "UTC"}, {"timezone": {"type": "string", "enum": ["UTC", "America/New_York", "Asia/Kolkata"]}}),
    ("Return a get_time call for Asia/Kolkata.", "get_time", {"timezone": "Asia/Kolkata"}, {"timezone": {"type": "string", "enum": ["UTC", "America/New_York", "Asia/Kolkata"]}}),
    ("Return a convert_currency call to INR.", "convert_currency", {"amount": 10, "from": "USD", "to": "INR"}, {
        "amount": {"type": "integer", "enum": [1, 5, 10, 20]},
        "from": {"type": "string", "enum": ["USD", "EUR"]},
        "to": {"type": "string", "enum": ["INR", "USD", "EUR"]},
    }),
    ("Return a convert_currency call from EUR to USD for 5.", "convert_currency", {"amount": 5, "from": "EUR", "to": "USD"}, {
        "amount": {"type": "integer", "enum": [1, 5, 10, 20]},
        "from": {"type": "string", "enum": ["USD", "EUR"]},
        "to": {"type": "string", "enum": ["INR", "USD", "EUR"]},
    }),
    ("Return a get_weather call for a city.", "get_weather", {"city": "Paris"}, {"city": {"type": "string", "enum": ["Paris", "London", "Tokyo"]}}),
    ("Return a get_time call for New York.", "get_time", {"timezone": "America/New_York"}, {"timezone": {"type": "string", "enum": ["UTC", "America/New_York", "Asia/Kolkata"]}}),
]


def schema_for(name: str, args_schema: dict) -> dict:
    return {
        "type": "object",
        "properties": {
            "name": {"type": "string", "enum": ["get_weather", "get_time", "convert_currency"]},
            "arguments": {"type": "object", "properties": args_schema,
                          "required": list(args_schema), "additionalProperties": False},
        },
        "required": ["name", "arguments"], "additionalProperties": False,
    }


def top2_margin(values: torch.Tensor) -> float:
    best = torch.topk(values, min(2, values.numel())).values
    return float((best[0] - best[1]).item()) if len(best) > 1 else float("inf")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--thresholds", type=float, nargs="+", default=[0.02, 0.05, 0.1])
    args = ap.parse_args()
    if not torch.cuda.is_available():
        raise SystemExit("CUDA required")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.use_deterministic_algorithms(True)
    tok = AutoTokenizer.from_pretrained(MODEL, use_fast=True)
    fp = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.float32, attn_implementation="eager").to("cuda").eval()
    bf = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.bfloat16, attn_implementation="eager").to("cuda").eval()
    # Keep a single FP32 vocabulary projection for candidate-only correction.
    fp_head_w = fp.lm_head.weight.detach()
    fp_head_b = fp.lm_head.bias.detach() if fp.lm_head.bias is not None else None
    props = torch.cuda.get_device_properties(0)
    result = {"model": MODEL, "gpu": props.name, "compute_capability": f"{props.major}.{props.minor}",
              "torch": torch.__version__, "cuda": torch.version.cuda,
              "thresholds": args.thresholds, "task_count": len(TASKS), "runs": [],
              "note": "Prompt-level constrained JSON probe. Candidate correction recomputes only grammar-legal lm_head rows over BF16 body states; this is not a production kernel."}
    started_all = time.perf_counter()
    for task_id, (request, expected_name, expected_args, arg_schema) in enumerate(TASKS):
        schema = schema_for(expected_name, arg_schema)
        parser = JsonSchemaParser(schema)
        allowed_fn = build_transformers_prefix_allowed_tokens_fn(tok, parser)
        prompt = tok.apply_chat_template([{"role": "user", "content": request + " Return only the JSON tool call."}],
                                        tokenize=False, add_generation_prompt=True)
        input_ids = tok(prompt, return_tensors="pt", add_special_tokens=False).input_ids.to("cuda")
        generated = fp.generate(input_ids, max_new_tokens=128, do_sample=False,
                                 prefix_allowed_tokens_fn=allowed_fn, pad_token_id=tok.eos_token_id,
                                 eos_token_id=tok.eos_token_id)
        prompt_len = input_ids.shape[1]
        full = generated
        suffix = full[0, prompt_len:].tolist()
        text = tok.decode(suffix, skip_special_tokens=True)
        try:
            parsed = json.loads(text)
            valid_json = True
        except Exception:
            parsed, valid_json = None, False

        with torch.inference_mode():
            fp_out = fp(input_ids=full, output_hidden_states=True, use_cache=False)
            bf_out = bf(input_ids=full, output_hidden_states=True, use_cache=False)
        # The logit at prefix position j-1 predicts generated token j.
        steps = len(suffix)
        start = prompt_len - 1
        fp_logits = fp_out.logits[0, start:start + steps].float()
        bf_logits = bf_out.logits[0, start:start + steps].float()
        bf_hidden = bf_out.hidden_states[-1][0, start:start + steps]
        full_top1, legal_top1 = 0, 0
        legal_flips, n_legal, sum_allowed, full_triggers = 0, 0, 0, 0
        step_records = []
        for i in range(steps):
            prefix = full[0, :prompt_len + i].tolist()
            allowed = allowed_fn(0, torch.tensor(prefix, dtype=torch.long))
            if hasattr(allowed, "allowed_tokens"):
                allowed = allowed.allowed_tokens
            if not allowed:
                continue
            allowed_t = torch.tensor(list(allowed), dtype=torch.long, device="cuda")
            b = bf_logits[i]
            f = fp_logits[i]
            b_legal = b.index_select(0, allowed_t)
            f_legal = f.index_select(0, allowed_t)
            margin_full = top2_margin(b)
            margin_legal = top2_margin(b_legal)
            b_id = allowed_t[b_legal.argmax()]
            f_id = allowed_t[f_legal.argmax()]
            legal_flips += int(b_id.item() != f_id.item())
            n_legal += 1
            sum_allowed += len(allowed)
            full_triggers += int(margin_full <= min(args.thresholds))
            # FP32 lm_head candidate rerank over grammar-legal vocabulary rows.
            h = bf_hidden[i].float().reshape(1, -1)
            candidate_w = fp_head_w.index_select(0, allowed_t)
            candidate_b = fp_head_b.index_select(0, allowed_t) if fp_head_b is not None else None
            corrected = F.linear(h, candidate_w, candidate_b).reshape(-1)
            corrected_id = allowed_t[corrected.argmax()]
            step_records.append({"legal_count": len(allowed), "vocab_size": int(b.numel()),
                                 "legal_fraction": len(allowed) / b.numel(),
                                 "margin_full_vocab_bf16": margin_full,
                                 "margin_legal_bf16": margin_legal,
                                 "bf16_legal_token": int(b_id), "fp32_legal_token": int(f_id),
                                 "bf16_body_fp32_legal_head_token": int(corrected_id),
                                 "legal_argmax_flip": int(b_id.item() != f_id.item())})
        modes = {}
        for tau in args.thresholds:
            triggers_full = sum(r["margin_full_vocab_bf16"] <= tau for r in step_records)
            triggers_legal = sum(r["margin_legal_bf16"] <= tau for r in step_records)
            legal_false = sum((r["margin_full_vocab_bf16"] <= tau) and (r["margin_legal_bf16"] > tau) for r in step_records)
            full_missed = sum((r["margin_full_vocab_bf16"] > tau) and (r["margin_legal_bf16"] <= tau) for r in step_records)
            modes[str(tau)] = {"full_vocab_gate_triggers": triggers_full,
                               "legal_set_gate_triggers": triggers_legal,
                               "full_gate_false_triggers_vs_legal": legal_false,
                               "full_gate_misses_vs_legal": full_missed,
                               "full_gate_argmax_matches_fp32_fraction": sum(
                                   (r["bf16_legal_token"] if r["margin_full_vocab_bf16"] > tau
                                    else r["bf16_body_fp32_legal_head_token"]) == r["fp32_legal_token"]
                                   for r in step_records) / max(1, len(step_records)),
                               "legal_gate_argmax_matches_fp32_fraction": sum(
                                   (r["bf16_legal_token"] if r["margin_legal_bf16"] > tau
                                    else r["bf16_body_fp32_legal_head_token"]) == r["fp32_legal_token"]
                                   for r in step_records) / max(1, len(step_records)),
                               "full_gate_recall_of_legal_argmax_flips": sum(
                                   r["legal_argmax_flip"] and r["margin_full_vocab_bf16"] <= tau
                                   for r in step_records) / max(1, legal_flips),
                               "legal_gate_recall_of_legal_argmax_flips": sum(
                                   r["legal_argmax_flip"] and r["margin_legal_bf16"] <= tau
                                   for r in step_records) / max(1, legal_flips),
                               "legal_head_rows_recomputed_by_legal_gate": sum(
                                   r["legal_count"] for r in step_records if r["margin_legal_bf16"] <= tau)}
        result["runs"].append({"task_id": task_id, "request": request, "completion": text,
                               "valid_json": valid_json,
                               "task_correct": bool(valid_json and parsed.get("name") == expected_name
                                                    and parsed.get("arguments") == expected_args),
                               "expected_name": expected_name,
                               "expected_args": expected_args, "parsed": parsed,
                               "generated_tokens": steps, "steps_scored": len(step_records),
                               "legal_argmax_flips_bf16_vs_fp32": legal_flips,
                               "mean_allowed_tokens": sum_allowed / max(1, n_legal),
                               "mean_allowed_fraction": (sum_allowed / max(1, n_legal)) / fp.config.vocab_size,
                               "threshold_summary": modes, "steps": step_records})
        del fp_out, bf_out
        torch.cuda.empty_cache()
    result["elapsed_seconds"] = time.perf_counter() - started_all
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "runs"}, indent=2))
    print(json.dumps([{k: v for k, v in r.items() if k != "steps"} for r in result["runs"]], indent=2))


if __name__ == "__main__":
    main()
