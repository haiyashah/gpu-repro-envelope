import unittest

from bench.timeout_safety_liveness import analyze


class TimeoutSafetyLivenessTests(unittest.TestCase):
    def test_timeout_alone_cannot_guarantee_both_reuse_and_safety(self):
        result = analyze()
        self.assertTrue(result["worlds_are_indistinguishable_to_receiver"])
        self.assertTrue(result["no_timeout_only_policy_has_both_guarantees"])
        self.assertFalse(any(
            result["policy_satisfies_safety_and_reclamation_in_both_worlds"].values()
        ))

    def test_reuse_unsafe_in_delayed_world_and_hold_loses_reclamation(self):
        result = analyze()
        self.assertTrue(
            result["policies"]["reuse_now"][1]["foreign_write_possible"]
        )
        self.assertFalse(
            result["policies"]["hold_forever"][0]["reclaimed"]
        )


if __name__ == "__main__":
    unittest.main()
