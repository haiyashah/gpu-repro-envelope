import unittest

from bench.kv_protocol_state_space import analyze


class KVProtocolStateSpaceTests(unittest.TestCase):
    def test_unsafe_baseline_has_a_reachable_cross_request_read(self):
        result = analyze()
        self.assertTrue(result["properties"]["unsafe_baseline_has_counterexample"])
        self.assertIsNotNone(result["scenarios"]["unsafe_baseline"]["counterexample"])

    def test_deferred_release_and_read_guard_close_late_write_path(self):
        result = analyze()
        self.assertTrue(result["properties"]["deferred_release_blocks_late_writer_leak"])
        self.assertTrue(result["properties"]["read_guard_fails_closed_on_foreign_content"])

    def test_short_handoff_cannot_be_decoded_as_complete(self):
        result = analyze()
        self.assertTrue(result["properties"]["strict_transfer_check_fails_closed_on_placeholder"])
        self.assertTrue(result["properties"]["combined_defenses_block_all_modeled_leaks"])

    def test_reused_room_id_requires_generation_tagged_ack(self):
        result = analyze()
        self.assertTrue(result["properties"]["stale_room_ack_can_release_live_page"])
        self.assertTrue(result["properties"]["generation_tag_rejects_stale_ack"])

    def test_device_timeout_release_has_late_write_counterexample(self):
        result = analyze()
        self.assertTrue(result["properties"]["release_on_timeout_has_late_write_counterexample"])
        self.assertTrue(result["properties"]["quarantine_on_timeout_fails_closed"])


if __name__ == "__main__":
    unittest.main()
