import unittest

from bench.kv_page_model_check import analyze


class KVPageSafetyModelTests(unittest.TestCase):
    def test_unsafe_protocols_have_counterexamples(self):
        result = analyze()
        self.assertTrue(result["properties"]["unsafe_late_writer_has_counterexample"])
        self.assertTrue(result["properties"]["unsafe_rejected_prefill_has_counterexample"])

    def test_read_guard_and_quarantine_block_late_writer_leaks(self):
        result = analyze()
        self.assertTrue(result["properties"]["read_guard_blocks_every_foreign_page_read"])
        self.assertTrue(result["properties"]["quarantine_blocks_every_foreign_page_read"])

    def test_rejected_or_short_prefill_fails_closed(self):
        result = analyze()
        self.assertTrue(result["properties"]["strict_admission_blocks_every_rejected_prefill_read"])


if __name__ == "__main__":
    unittest.main()
