import importlib.util
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parents[1] / "src" / "fingerprint.py"
spec = importlib.util.spec_from_file_location("fingerprint", MODULE_PATH)
fingerprint = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(fingerprint)


class DifferenceTests(unittest.TestCase):
    def test_equal_nested_records_have_no_differences(self):
        value = {"gpu": {"name": "A100", "driver": "550"}, "packages": {"torch": "2.5"}}
        self.assertEqual(fingerprint.differences(value, value), [])

    def test_reports_changed_and_missing_leaves(self):
        left = {"gpu": {"name": "A100", "driver": "550"}, "packages": {"torch": "2.5"}}
        right = {"gpu": {"name": "H100", "driver": "550"}, "container": {"digest": "sha256:x"}, "packages": {"torch": "2.5"}}
        self.assertEqual(
            fingerprint.differences(left, right),
            [
                {"path": "container", "left": "<missing>", "right": {"digest": "sha256:x"}},
                {"path": "gpu.name", "left": "A100", "right": "H100"},
            ],
        )

    def test_list_values_are_compared_as_atomic_fields(self):
        self.assertEqual(fingerprint.differences({"gpu": ["A100", "H100"]}, {"gpu": ["H100"]})[0]["path"], "gpu")


if __name__ == "__main__":
    unittest.main()
