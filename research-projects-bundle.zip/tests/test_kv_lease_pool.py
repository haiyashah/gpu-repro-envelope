import unittest

from src.kv_lease_pool import CapacityUnavailable, KVLeasePool, LeaseState


class KVLeasePoolTests(unittest.TestCase):
    def test_timeout_quarantines_pages_until_all_ranks_drain(self):
        pool = KVLeasePool(3)
        lease = pool.allocate("A", 2, expected_ranks={0, 1})
        pages = {0, 1}
        pool.record_write_posted(lease)
        pool.abort(lease)
        pool.acknowledge_drained(lease, rank=0, generation=lease.generation)
        pool.timeout(lease)

        self.assertEqual(pool.state_of(lease), LeaseState.QUARANTINED)
        self.assertEqual(pool.quarantined_pages, pages)
        next_lease = pool.allocate("B", 1, expected_ranks=set())
        self.assertNotIn(next_lease, {pool.owner_of(page) for page in pages})

        pool.record_write_completed(lease)
        pool.acknowledge_drained(lease, rank=1, generation=lease.generation)
        self.assertEqual(pool.state_of(lease), LeaseState.RELEASED)
        self.assertEqual(pool.quarantined_pages, frozenset())

    def test_old_generation_ack_cannot_release_reused_request_id(self):
        pool = KVLeasePool(1)
        old = pool.allocate("same-room", 1, expected_ranks={3})
        pool.abort(old)
        self.assertTrue(pool.acknowledge_drained(old, rank=3, generation=old.generation))
        new = pool.allocate("same-room", 1, expected_ranks={3})
        pool.abort(new)

        self.assertFalse(pool.acknowledge_drained(new, rank=3, generation=old.generation))
        self.assertEqual(pool.state_of(new), LeaseState.ABORTING)

    def test_quarantine_exhaustion_refuses_reuse_instead_of_leaking(self):
        pool = KVLeasePool(1)
        a = pool.allocate("A", 1, expected_ranks={0})
        pool.abort(a)
        pool.timeout(a)

        with self.assertRaises(CapacityUnavailable):
            pool.allocate("B", 1, expected_ranks=set())

    def test_ack_without_local_write_completion_does_not_release(self):
        pool = KVLeasePool(1)
        lease = pool.allocate("A", 1, expected_ranks={0})
        pool.record_write_posted(lease)
        pool.abort(lease)
        pool.acknowledge_drained(lease, rank=0, generation=lease.generation)

        self.assertEqual(pool.state_of(lease), LeaseState.ABORTING)
        self.assertFalse(pool.free_pages)

    def test_transport_fence_is_the_only_non_ack_release_path(self):
        pool = KVLeasePool(1)
        lease = pool.allocate("A", 1, expected_ranks={0})
        pool.record_write_posted(lease)
        pool.abort(lease)
        pool.timeout(lease)
        pool.confirm_transport_fenced(lease)

        self.assertEqual(pool.state_of(lease), LeaseState.RELEASED)
        self.assertEqual(pool.free_pages, frozenset({0}))


if __name__ == "__main__":
    unittest.main()
