import unittest

from bench.cache_partition_conformance import (
    ConformanceError,
    Coverage,
    Probe,
    audit,
    audit_document,
    partitioned_key,
)


def make_probe(entrypoint, tier, relation, cache_hit):
    warm = (("tenant_salt", "team-A"),)
    candidate = warm if relation == "same" else (("tenant_salt", "team-B"),)
    return Probe(
        entrypoint, tier, "tenant_salt", relation, cache_hit, warm, candidate
    )


class CachePartitionConformanceTests(unittest.TestCase):
    def setUp(self):
        self.coverage = Coverage(
            entrypoints=("chat", "responses_tool_continuation"),
            tiers=("in_engine", "external_connector"),
            dimensions=("tenant_salt",),
            discovered_connectors=("memory", "lmcache"),
            covered_connectors=("memory", "lmcache"),
        )

    def test_domain_separated_key_changes_for_each_identity_dimension(self):
        base = dict(
            model_fingerprint="model@revision-a",
            prefix_block_ids=("p0", "p1"),
            required_dimensions=("tenant_salt", "lora_name"),
        )
        a = partitioned_key(
            **base, dimensions={"tenant_salt": "team-A", "lora_name": "adapter"}
        )
        same = partitioned_key(
            **base, dimensions={"tenant_salt": "team-A", "lora_name": "adapter"}
        )
        changed_salt = partitioned_key(
            **base, dimensions={"tenant_salt": "team-B", "lora_name": "adapter"}
        )
        changed_lora = partitioned_key(
            **base, dimensions={"tenant_salt": "team-A", "lora_name": "other"}
        )
        self.assertEqual(a, same)
        self.assertNotEqual(a, changed_salt)
        self.assertNotEqual(a, changed_lora)

    def test_behavior_matrix_requires_hit_and_isolation_control_on_every_path(self):
        probes = []
        for entrypoint in self.coverage.entrypoints:
            for tier in self.coverage.tiers:
                probes.extend((
                    make_probe(entrypoint, tier, "same", True),
                    make_probe(entrypoint, tier, "different", False),
                ))
        result = audit(probes, self.coverage)
        self.assertTrue(result["passed"])
        self.assertEqual(result["expected_paths"], 4)
        self.assertEqual(result["probe_count"], 8)

    def test_json_adapter_report_uses_same_conformance_rules(self):
        document = {
            "coverage": {
                "entrypoints": ["chat"],
                "tiers": ["in_engine"],
                "dimensions": ["tenant_salt"],
            },
            "probes": [
                {
                    "entrypoint": "chat",
                    "tier": "in_engine",
                    "dimension": "tenant_salt",
                    "relation": "same",
                    "cache_hit": True,
                    "warm_identity": [["tenant_salt", "team-A"]],
                    "probe_identity": [["tenant_salt", "team-A"]],
                },
                {
                    "entrypoint": "chat",
                    "tier": "in_engine",
                    "dimension": "tenant_salt",
                    "relation": "different",
                    "cache_hit": False,
                    "warm_identity": [["tenant_salt", "team-A"]],
                    "probe_identity": [["tenant_salt", "team-B"]],
                },
            ],
        }
        self.assertTrue(audit_document(document)["passed"])

    def test_catches_salt_dropped_on_tool_continuation(self):
        probes = []
        for entrypoint in self.coverage.entrypoints:
            for tier in self.coverage.tiers:
                probes.extend((
                    make_probe(entrypoint, tier, "same", True),
                    make_probe(
                        entrypoint,
                        tier,
                        "different",
                        entrypoint == "responses_tool_continuation",
                    ),
                ))
        with self.assertRaisesRegex(ConformanceError, "isolation violation"):
            audit(probes, self.coverage)

    def test_rejects_a_false_pass_when_cache_is_disabled(self):
        probes = []
        for entrypoint in self.coverage.entrypoints:
            for tier in self.coverage.tiers:
                probes.extend((
                    make_probe(entrypoint, tier, "same", False),
                    make_probe(entrypoint, tier, "different", False),
                ))
        with self.assertRaisesRegex(ConformanceError, "positive control did not hit"):
            audit(probes, self.coverage)

    def test_rejects_a_mislabeled_different_identity_probe(self):
        probes = []
        for entrypoint in self.coverage.entrypoints:
            for tier in self.coverage.tiers:
                probes.extend((
                    make_probe(entrypoint, tier, "same", True),
                    Probe(
                        entrypoint,
                        tier,
                        "tenant_salt",
                        "different",
                        False,
                        (("tenant_salt", "team-A"),),
                        (("tenant_salt", "team-A"),),
                    ),
                ))
        with self.assertRaisesRegex(ConformanceError, "different control.*changes"):
            audit(probes, self.coverage)

    def test_registry_gate_fails_when_a_new_connector_has_no_case(self):
        probes = []
        for entrypoint in self.coverage.entrypoints:
            for tier in self.coverage.tiers:
                probes.extend((
                    make_probe(entrypoint, tier, "same", True),
                    make_probe(entrypoint, tier, "different", False),
                ))
        coverage = Coverage(
            entrypoints=self.coverage.entrypoints,
            tiers=self.coverage.tiers,
            dimensions=self.coverage.dimensions,
            discovered_connectors=("memory", "lmcache", "new_connector"),
            covered_connectors=("memory", "lmcache"),
        )
        with self.assertRaisesRegex(ConformanceError, "uncovered registered connector"):
            audit(probes, coverage)

    def test_rejects_probe_outside_declared_coverage(self):
        probes = [
            make_probe(entrypoint, tier, relation, hit)
            for entrypoint in self.coverage.entrypoints
            for tier in self.coverage.tiers
            for relation, hit in (("same", True), ("different", False))
        ]
        probes.append(Probe(
            "unlisted_endpoint", "in_engine", "tenant_salt", "same", True,
            (("tenant_salt", "team-A"),), (("tenant_salt", "team-A"),),
        ))
        with self.assertRaisesRegex(ConformanceError, "outside declared coverage"):
            audit(probes, self.coverage)


if __name__ == "__main__":
    unittest.main()
