import importlib.util
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parents[1] / "src" / "mm_cache_guard.py"
spec = importlib.util.spec_from_file_location("mm_cache_guard", MODULE_PATH)
guard = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(guard)


class MediaCacheIdentityTests(unittest.TestCase):
    def setUp(self):
        self.common = {
            "secret": b"test-secret-32-bytes-long-enough!!",
            "tenant_id": "tenant-a",
            "model_revision": "model@sha256:abc",
            "processor_revision": "processor-v4",
            "modality": "audio",
            "client_media_id": "item-17",
        }

    def key(self, payload, **overrides):
        args = {**self.common, **overrides, "payload": payload}
        return guard.derive_media_cache_id(**args)

    def test_same_content_reuses_identity(self):
        self.assertEqual(self.key(b"same media"), self.key(b"same media"))

    def test_same_shape_collision_changes_identity(self):
        # The reported silent case: one client ID and equal-length media, but
        # distinct content. A count/shape-only cache check cannot detect this.
        first = self.key(b"payload-A")
        second = self.key(b"payload-B")
        self.assertEqual(len(b"payload-A"), len(b"payload-B"))
        self.assertNotEqual(first, second)

    def test_identity_is_tenant_scoped(self):
        self.assertNotEqual(self.key(b"media"), self.key(b"media", tenant_id="tenant-b"))

    def test_prefix_salt_is_stable_and_tenant_scoped(self):
        a1 = guard.derive_tenant_prefix_cache_salt(
            secret=self.common["secret"], tenant_id="tenant-a"
        )
        a2 = guard.derive_tenant_prefix_cache_salt(
            secret=self.common["secret"], tenant_id="tenant-a"
        )
        b = guard.derive_tenant_prefix_cache_salt(
            secret=self.common["secret"], tenant_id="tenant-b"
        )
        self.assertEqual(a1, a2)
        self.assertNotEqual(a1, b)
        self.assertNotEqual(a1, self.key(b"media"))

    def test_model_and_processor_revisions_invalidate(self):
        base = self.key(b"media")
        self.assertNotEqual(base, self.key(b"media", model_revision="model@sha256:def"))
        self.assertNotEqual(base, self.key(b"media", processor_revision="processor-v5"))

    def test_modality_and_client_namespace_are_domain_separated(self):
        base = self.key(b"media")
        self.assertNotEqual(base, self.key(b"media", modality="image"))
        self.assertNotEqual(base, self.key(b"media", client_media_id="another-item"))

    def test_key_does_not_reveal_input_fields(self):
        key = self.key(b"secret-media")
        for fragment in ("tenant-a", "item-17", "model@sha256:abc"):
            self.assertNotIn(fragment, key)
        self.assertTrue(key.startswith("mmci1_"))

    def test_rejects_missing_or_weak_secret_and_missing_payload(self):
        with self.assertRaises(ValueError):
            self.key(b"media", secret=b"short")
        with self.assertRaises(ValueError):
            guard.derive_media_cache_id(**{**self.common, "payload": None})

    def test_field_boundaries_prevent_concatenation_ambiguity(self):
        a = self.key(b"m", tenant_id="ab", model_revision="c")
        b = self.key(b"m", tenant_id="a", model_revision="bc")
        self.assertNotEqual(a, b)


if __name__ == "__main__":
    unittest.main()
