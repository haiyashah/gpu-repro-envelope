#!/usr/bin/env python3
"""Capture the execution environment that can change GPU-kernel behavior."""
from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

ENV_KEYS = (
    "CUDA_VISIBLE_DEVICES",
    "CUDA_HOME",
    "CUDA_PATH",
    "TORCH_CUDA_ARCH_LIST",
    "NVIDIA_TF32_OVERRIDE",
    "PYTORCH_CUDA_ALLOC_CONF",
    "CMAKE_CUDA_COMPILER",
)
PACKAGES = ("torch", "triton", "nvidia-cudnn-cu12", "nvidia-nccl-cu12", "flash-attn")


def command_output(argv: list[str], timeout: int = 8) -> dict[str, Any]:
    exe = shutil.which(argv[0])
    if not exe:
        return {"available": False}
    try:
        p = subprocess.run([exe, *argv[1:]], text=True, capture_output=True, timeout=timeout)
        return {
            "available": True,
            "exit_code": p.returncode,
            "stdout": p.stdout.strip()[-12000:],
            "stderr": p.stderr.strip()[-2000:],
        }
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": True, "error": type(exc).__name__ + ": " + str(exc)}


def package_versions() -> dict[str, str | None]:
    out: dict[str, str | None] = {}
    for name in PACKAGES:
        try:
            out[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            out[name] = None
    return out


def capture() -> dict[str, Any]:
    return {
        "schema_version": 1,
        "host": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "python": sys.version,
            "implementation": platform.python_implementation(),
        },
        "gpu": command_output([
            "nvidia-smi", "--query-gpu=name,uuid,driver_version,memory.total,compute_cap",
            "--format=csv,noheader,nounits",
        ]),
        "cuda_compiler": command_output(["nvcc", "--version"]),
        "container": {
            "docker_version": command_output(["docker", "--version"]),
            "nvidia_container_toolkit": command_output(["nvidia-container-cli", "--version"]),
        },
        "packages": package_versions(),
        "cuda_environment": {key: os.environ.get(key) for key in ENV_KEYS if key in os.environ},
    }


def differences(left: Any, right: Any, path: str = "") -> list[dict[str, Any]]:
    """Return leaf-level mismatches, treating absent keys as distinct values."""
    if isinstance(left, dict) and isinstance(right, dict):
        rows: list[dict[str, Any]] = []
        for key in sorted(set(left) | set(right)):
            child = f"{path}.{key}" if path else key
            if key not in left or key not in right:
                rows.append({"path": child, "left": left.get(key, "<missing>"), "right": right.get(key, "<missing>")})
            else:
                rows.extend(differences(left[key], right[key], child))
        return rows
    if left != right:
        return [{"path": path, "left": left, "right": right}]
    return []


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    cap = sub.add_parser("capture", help="write a JSON environment fingerprint")
    cap.add_argument("output", type=Path)
    diff = sub.add_parser("diff", help="compare two fingerprints")
    diff.add_argument("left", type=Path)
    diff.add_argument("right", type=Path)
    args = parser.parse_args()
    if args.command == "capture":
        args.output.write_text(json.dumps(capture(), indent=2, sort_keys=True) + "\n")
        print(f"wrote {args.output}")
    else:
        a, b = json.loads(args.left.read_text()), json.loads(args.right.read_text())
        rows = differences(a, b)
        print(json.dumps(rows, indent=2))
        raise SystemExit(1 if rows else 0)


if __name__ == "__main__":
    main()
