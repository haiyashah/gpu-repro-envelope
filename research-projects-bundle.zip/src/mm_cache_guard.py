"""Tenant-scoped, content-bound identities for caller-addressed media caches.

This is an ingress-side reference implementation. It does not modify vLLM's
cache internals: a gateway can replace client-provided media UUIDs with the
opaque value returned here before forwarding the request.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import struct
from typing import Iterable

_DOMAIN = b"mm-cache-identity/v1"
_SALT_DOMAIN = b"vllm-prefix-cache-salt/v1"
_KEY_PREFIX = "mmci1_"
_SALT_PREFIX = "vllm-tenant-salt-v1_"


def _encode_field(value: str) -> bytes:
    if not isinstance(value, str) or not value:
        raise ValueError("identity fields must be non-empty strings")
    encoded = value.encode("utf-8")
    if len(encoded) > 0xFFFFFFFF:
        raise ValueError("identity field is too large")
    return struct.pack(">I", len(encoded)) + encoded


def _validate_secret(secret: bytes) -> None:
    if not isinstance(secret, bytes) or len(secret) < 16:
        raise ValueError("secret must contain at least 16 bytes")


def derive_tenant_prefix_cache_salt(*, secret: bytes, tenant_id: str) -> str:
    """Return a stable, opaque vLLM ``cache_salt`` value for one tenant."""
    _validate_secret(secret)
    mac = hmac.new(secret, digestmod=hashlib.sha256)
    mac.update(struct.pack(">I", len(_SALT_DOMAIN)))
    mac.update(_SALT_DOMAIN)
    mac.update(_encode_field(tenant_id))
    token = base64.urlsafe_b64encode(mac.digest()).decode("ascii").rstrip("=")
    return _SALT_PREFIX + token


def derive_media_cache_id(
    *,
    secret: bytes,
    tenant_id: str,
    model_revision: str,
    processor_revision: str,
    modality: str,
    payload: bytes | bytearray | memoryview,
    client_media_id: str | None = None,
) -> str:
    """Return an opaque ID bound to tenant, model, preprocessing and media bytes.

    The payload must be the exact byte sequence whose processed representation
    is cached. Callers handling URLs should fetch and validate them in their own
    SSRF-safe media layer before calling this function.

    ``client_media_id`` remains a namespace hint, but never substitutes for the
    payload digest. Same client IDs with different payload bytes therefore miss.
    """
    _validate_secret(secret)
    if payload is None:
        raise ValueError("payload bytes are required for content binding")

    fields: Iterable[str] = (tenant_id, model_revision, processor_revision, modality)
    mac = hmac.new(secret, digestmod=hashlib.sha256)
    mac.update(struct.pack(">I", len(_DOMAIN)))
    mac.update(_DOMAIN)
    for field in fields:
        mac.update(_encode_field(field))
    if client_media_id is None:
        mac.update(b"\x00")
    else:
        mac.update(b"\x01")
        mac.update(_encode_field(client_media_id))
    media = memoryview(payload).cast("B")
    mac.update(struct.pack(">Q", len(media)))
    mac.update(media)
    token = base64.urlsafe_b64encode(mac.digest()).decode("ascii").rstrip("=")
    return _KEY_PREFIX + token
