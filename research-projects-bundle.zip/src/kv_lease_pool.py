"""Reference fail-closed KV page leasing for asynchronous transfer systems.

This is a small control-plane reference implementation. It is not wired into
SGLang, a CUDA allocator, or an RDMA backend. Its contract is deliberately
strict: deadlines can quarantine memory, but only a positive drain/fence proof
can make a page allocatable again.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class LeaseError(RuntimeError):
    pass


class CapacityUnavailable(LeaseError):
    pass


class LeaseState(str, Enum):
    ACTIVE = "active"
    ABORTING = "aborting"
    QUARANTINED = "quarantined"
    RELEASED = "released"


@dataclass(frozen=True)
class LeaseToken:
    request_id: str
    generation: int


@dataclass
class _Lease:
    token: LeaseToken
    pages: tuple[int, ...]
    expected_ranks: frozenset[int]
    acked_ranks: set[int] = field(default_factory=set)
    outstanding_writes: int = 0
    state: LeaseState = LeaseState.ACTIVE


class KVLeasePool:
    """A finite page allocator that never reuses a timed-out lease blindly.

    ``timeout`` fails closed by quarantining pages. A request's pages return to
    the free pool only after every expected sender rank acknowledges drain and
    all locally tracked writes complete, or after the caller reports that the
    transport has been fenced. Callers must make that proof trustworthy.
    """

    def __init__(self, capacity: int):
        if capacity < 1:
            raise ValueError("capacity must be positive")
        self.capacity = capacity
        self._free = set(range(capacity))
        self._generation = 0
        self._leases: dict[LeaseToken, _Lease] = {}
        self._active_request: dict[str, LeaseToken] = {}
        self._page_owner: dict[int, LeaseToken] = {}

    @property
    def free_pages(self) -> frozenset[int]:
        return frozenset(self._free)

    @property
    def quarantined_pages(self) -> frozenset[int]:
        return frozenset(
            page
            for lease in self._leases.values()
            if lease.state == LeaseState.QUARANTINED
            for page in lease.pages
        )

    def allocate(
        self,
        request_id: str,
        page_count: int,
        *,
        expected_ranks: set[int] | frozenset[int],
    ) -> LeaseToken:
        if request_id in self._active_request:
            raise LeaseError(f"request already has a lease: {request_id}")
        if page_count < 1:
            raise ValueError("page_count must be positive")
        if page_count > len(self._free):
            raise CapacityUnavailable(
                f"need {page_count} KV pages, only {len(self._free)} are safely reusable"
            )
        pages = tuple(sorted(self._free)[:page_count])
        self._free.difference_update(pages)
        self._generation += 1
        token = LeaseToken(request_id, self._generation)
        lease = _Lease(token, pages, frozenset(expected_ranks))
        self._leases[token] = lease
        self._active_request[request_id] = token
        for page in pages:
            self._page_owner[page] = token
        return token

    def record_write_posted(self, token: LeaseToken) -> None:
        lease = self._get(token)
        if lease.state != LeaseState.ACTIVE:
            raise LeaseError(f"cannot post a write for a {lease.state.value} lease")
        lease.outstanding_writes += 1

    def record_write_completed(self, token: LeaseToken) -> None:
        lease = self._get(token)
        if lease.outstanding_writes == 0:
            raise LeaseError("write completion without a posted write")
        lease.outstanding_writes -= 1
        self._release_if_drained(lease)

    def abort(self, token: LeaseToken) -> None:
        lease = self._get(token)
        if lease.state == LeaseState.RELEASED:
            return
        if lease.state == LeaseState.ACTIVE:
            lease.state = LeaseState.ABORTING
        self._release_if_drained(lease)

    def acknowledge_drained(
        self, token: LeaseToken, *, rank: int, generation: int
    ) -> bool:
        """Accept only an expected rank's ACK for this exact lease generation."""
        lease = self._leases.get(token)
        if lease is None or generation != token.generation:
            return False
        if lease.state not in (LeaseState.ABORTING, LeaseState.QUARANTINED):
            return False
        if rank not in lease.expected_ranks:
            return False
        lease.acked_ranks.add(rank)
        self._release_if_drained(lease)
        return True

    def timeout(self, token: LeaseToken) -> None:
        """Mark the lease unsafe to reuse; timeout itself never frees pages."""
        lease = self._get(token)
        if lease.state == LeaseState.ABORTING:
            lease.state = LeaseState.QUARANTINED

    def confirm_transport_fenced(self, token: LeaseToken) -> None:
        """Release after an out-of-band fence proves no remote writes can land.

        The serving integration must supply this guarantee. A timer, socket
        close, or missing ACK is not sufficient evidence of a fence.
        """
        lease = self._get(token)
        if lease.state not in (LeaseState.ABORTING, LeaseState.QUARANTINED):
            raise LeaseError("transport fencing only applies to an aborted lease")
        lease.outstanding_writes = 0
        lease.acked_ranks = set(lease.expected_ranks)
        self._release(lease)

    def owner_of(self, page: int) -> LeaseToken | None:
        return self._page_owner.get(page)

    def state_of(self, token: LeaseToken) -> LeaseState:
        return self._get(token).state

    def _release_if_drained(self, lease: _Lease) -> None:
        if (
            lease.state in (LeaseState.ABORTING, LeaseState.QUARANTINED)
            and lease.outstanding_writes == 0
            and lease.acked_ranks == set(lease.expected_ranks)
        ):
            self._release(lease)

    def _release(self, lease: _Lease) -> None:
        for page in lease.pages:
            if self._page_owner.get(page) != lease.token:
                raise LeaseError(f"page {page} ownership changed before release")
            del self._page_owner[page]
            self._free.add(page)
        self._active_request.pop(lease.token.request_id, None)
        lease.state = LeaseState.RELEASED

    def _get(self, token: LeaseToken) -> _Lease:
        try:
            return self._leases[token]
        except KeyError as error:
            raise LeaseError("unknown or stale lease token") from error
