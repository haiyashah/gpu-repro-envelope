# LinkedIn draft

A GPU reproducibility benchmark without same-device repeat controls cannot tell whether a measured difference came from a hardware change or ordinary run-to-run variation.

I started with the control.

I ran the same 500-step FP32 training job three times on an NVIDIA A40. Each run used the same seed, CPU-generated dataset, initialization, minibatch order, PyTorch deterministic algorithms, and disabled TF32.

All three runs produced the exact same final parameter SHA-256. They also reached the same result on 2,048 synthetic test examples: 99.316% accuracy and 0.01496 loss.

That is a small pilot, not a cross-GPU finding. It does not show that an A40 and H100 diverge, and it does not establish a general property of training. It tells me the baseline is bitwise repeatable in this one setup across three fresh processes.

Why start here? If two GPU configurations produce different weights, comparing one run against one run confounds architecture effects with ordinary repeat variation. A same-device control gives the comparison a baseline. The next experiment is to hold the software stack, data, initialization, and training order fixed while changing the GPU, then compare weight distance, logit RMS, prediction disagreement, and task metrics.

The code and preliminary result are here: https://github.com/haiyashah/gpu-repro-envelope

#GPUs #MachineLearningSystems #Reproducibility
