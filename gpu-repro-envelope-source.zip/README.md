# Same Seed, Different Trajectory?

## A controlled test of cross-GPU training reproducibility

The surprising question is not whether two GPUs return bit-identical floating-point results. They often will not. It is whether tiny, deterministic arithmetic differences change the *learning trajectory* enough to alter the trained model's decisions.

This repository tests that claim with fixed data, initialization, minibatch order, optimizer, and deterministic PyTorch settings. The current pilot measures repeated runs on one GPU. A cross-architecture comparison remains unmeasured, so the project does not yet estimate cross-GPU trajectory drift.

The initial scope is deliberately small: a synthetic nonlinear classification task, a compact MLP, FP32, and full-batch or fixed minibatches. This isolates hardware/runtime arithmetic from data-loader randomness, dropout, mixed precision, and distributed communication.

## Current status

This is a **single-GPU pilot**, not a cross-GPU result. Three independent A40 processes trained the same seed-7 FP32 workload for 500 steps with the same fixed CPU-generated data, initialization, and batch order. The final parameter SHA-256 matched across all three runs. All three reached 99.3164% test accuracy (2,034/2,048) and 0.0149633 test loss.

The pilot supports only this narrow statement: under this A40 software stack and procedure, the configured deterministic run was bitwise repeatable across three fresh processes for one seed. It does not test another GPU, another seed, another model, mixed precision, distributed training, or a production workload. It is not a new general claim about GPU reproducibility. See [the pilot record](experiments/PILOT_RESULTS.md).

## Capture an environment

```bash
python src/fingerprint.py capture env.json
```

The fingerprint records GPU/driver data from `nvidia-smi`, CUDA compiler information, selected package versions, container tooling, and a short allowlist of CUDA-related environment variables. It intentionally does not dump the full process environment, which can contain credentials.

Compare captures:

```bash
python src/fingerprint.py diff baseline.json replay.json
```

## Run a training trial

```bash
python bench/train_path.py --steps 500 --seed 7 --output runs/gpu-seed7-r1.json
python bench/aggregate.py runs --output runs/aggregate.json
```

The training script writes a JSON record and a `.pt` checkpoint file with environment details and checkpoint metrics. Each run has a content hash for its fixed CPU-generated dataset and initial weights. It does not download data. The aggregate script compares every matched pair and keeps same-GPU controls separate from cross-GPU pairs.

## Research question

When algorithm-level nondeterminism is disabled, does moving a fixed training procedure across GPU architectures produce trajectory differences larger than same-device repeat noise, and do those differences change held-out decisions?

### Pilot protocol

1. Run at least three same-device repetitions per seed to estimate execution noise.
2. Repeat the same seeds on each available GPU architecture, preserving software versions and the JSON dataset/initialization hashes.
3. Enable deterministic algorithms, disable TF32, and fix minibatch order. Record any unsupported deterministic operation as a failed condition.
4. Compare parameter distance and logit distance at checkpoints, along with held-out accuracy and prediction agreement.
5. Run a small seed sweep. Compare cross-device differences with the empirical distribution from same-device repeats; do not infer general behavior from one seed.
6. Publish all raw records, environment fingerprints, commands, exclusions, and analysis code.

### Falsifiable outcomes

- The effect is weak in this setup if cross-device trajectory/decision differences remain within same-device repeat variation across the seed sweep.
- The effect is supported in this setup if cross-device differences exceed same-device variation consistently, especially if a stable training recipe changes held-out decisions.

## Scope limits

A small pilot can establish reproducible examples and estimate feasibility. It cannot establish how often GPU training results change in the wider literature. Divergent weights alone do not mean meaningful model behavior changed; prediction agreement and task metrics are reported separately.
